
package exerciciosdebusca;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*@author leoal */
public class ExerciciosDeBusca {

    public static void main(String[] args) {
        //exercicio01();
        //exercicio02();
        //exercicio03();
        exercicio04();
                
    }
    
    private static int buscaSequencialNaoOrdenadaInt(int [] x, int num ){
        int retorno = -1;
        for (int i = 0; i < x.length; i++) {
            if(x[i] == num){
                retorno = i;
                break;
            }
        }
        return retorno;
    }
    private static String buscaSequencialNaoOrdenada(int [] x, int num ){
        int resultado;
        String retorno = "Número não encontrado!";
        for (int i = 0; i < x.length; i++) {
            if(x[i] == num){
                retorno = "Valor encontrado! Posição: "+ (i+1);
                break;
            }
        }
        return retorno;
    }
    private static String buscaSequencialOrdenadaString(int [] x, int num ){
        String retorno = "Número não encontrado!";
        for (int i = 0; i < x.length && num >= x[i]; i++) {
            if(x[i] == num){
                retorno = "Valor encontrado! Posição: "+ i;
                break;
            }
        }
        return retorno;
    }
    private static int buscaSequencialOrdenadaInt(int [] x, int num ){
        int retorno = -1;
        for (int i = 0; i < x.length && num >= x[i]; i++) {
            if(x[i] == num){
                retorno = i;
                break;
            }
        }
        return retorno;
    }
    private static String buscaSequencialOrdenadaString2(int [] x, String []y, int num ){
        String retorno = "Aluno não encontrado!";
        for (int i = 0; i < x.length && num >= x[i]; i++) {
            if(x[i] == num){
                retorno = "Aluno encontrado!\nRA: "+ (i+1) + "\nAluno: "+y[i];
                break;
            }
        }
        return retorno;
    }
    private static boolean buscaSequencialOrdenada(int [] x, int num ){
        boolean retorno = false;
        for (int i = 0; i < x.length && num >= x[i]; i++) {
            if(x[i] == num){
                retorno = true;
                break;
            }
        }
        return retorno;
    }
    
    private static void quickSortCresc(int[] x, int inicio, int fim) {
        int posicaoPivo;

        if (inicio < fim) {
            posicaoPivo = particaoCresc(x,inicio,fim);
            quickSortCresc(x, inicio, posicaoPivo-1);
            quickSortCresc(x, posicaoPivo + 1, fim);            
        }
    }
    private static int particaoCresc (int [] x, int inicio, int fim){
        int pivo, i, j ;
        
        pivo = x[inicio];
        i = inicio + 1;
        j = fim ; 
        
        while(i <= j){
            if(x[i] <= pivo){ //dec
                i++;                
            }else if (pivo < x[j]){ //ded
                j--;
            }else{
                troca(x,i,j);
                i++;
                j--;
            }
        }
        x[inicio] = x[j];
        x[j] = pivo;
        return j;
    }
    private static void troca(int [] x, int i, int j){
        int aux ; 
        aux = x[i];
        x[i] = x[j];
        x[j] = aux;
    }
    
    
    private static void exercicio01(){
        int x[] = new int[10];
        int num = -1;
        
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        for (int i = 0; i < x.length; i++) {
            x[i] = random.nextInt(21);            
        }
        System.out.println(Arrays.toString(x));
        System.out.println("Informe um número que deseja buscar: ");
        num = scanner.nextInt();
        
        System.out.println(buscaSequencialNaoOrdenada(x,num));
    }
    
    private static void exercicio02(){
        int naoOrdenado[]   = new int[2000];
        int ordenado[]      = new int[naoOrdenado.length];
        int num = -1;
        
        Random random   = new Random();
        Scanner scanner = new Scanner(System.in);
        
        for (int i = 0; i < naoOrdenado.length; i++) {
            naoOrdenado[i] = random.nextInt(2001);            
        }
        for (int j = 0; j < naoOrdenado.length; j++) { 
            ordenado[j] = naoOrdenado[j];
        }
        System.out.println(Arrays.toString(naoOrdenado));
        quickSortCresc(ordenado,0,ordenado.length-1);
        System.out.println(Arrays.toString(ordenado));
        System.out.println("Informe um número que deseja buscar: ");
        num = scanner.nextInt();
        
        LocalDateTime duracaoBuscaNaoOrdenadaIni    = LocalDateTime.now();
        buscaSequencialNaoOrdenada(naoOrdenado,num);
        LocalDateTime duracaoBuscaNaoOrdenadaFim    = LocalDateTime.now();
        /**/
        LocalDateTime duracaoBuscaOrdenadaIni       = LocalDateTime.now();
        buscaSequencialOrdenadaInt(ordenado,num);
        LocalDateTime duracaoBuscaOrdenadaFim       = LocalDateTime.now();
        
        long tempoExecNaoOrdenada   = ChronoUnit.NANOS.between(duracaoBuscaNaoOrdenadaIni, duracaoBuscaNaoOrdenadaFim);
        long tempoExecOrdenada      = ChronoUnit.NANOS.between(duracaoBuscaOrdenadaIni, duracaoBuscaOrdenadaFim);
        
        System.out.println("Duração Busca Não Ordenada:\nIniciou : "+duracaoBuscaNaoOrdenadaIni.format(DateTimeFormatter.ISO_TIME) +
                            "\nTerminou: "+duracaoBuscaNaoOrdenadaFim.format(DateTimeFormatter.ISO_TIME)+
                            "\nDuração Total: "+tempoExecNaoOrdenada+" nanosegundos.");
        if(buscaSequencialNaoOrdenadaInt(naoOrdenado, num)!= -1){
            System.out.println("Foi encontrado na posição: "+(buscaSequencialNaoOrdenadaInt(naoOrdenado, num)+1));
        }else{
            System.out.println("Esse valor não foi encontrado");
        }
        /**/
        System.out.println("Duração Busca Ordenada:\nIniciou : "+duracaoBuscaOrdenadaIni.format(DateTimeFormatter.ISO_TIME) +
                            "\nTerminou: "+duracaoBuscaOrdenadaFim.format(DateTimeFormatter.ISO_TIME)+
                            "\nDuração Total: "+tempoExecOrdenada+" nanosegundos.");
        
        if(buscaSequencialOrdenadaInt(ordenado, num)!= -1){
            System.out.println("Foi encontrado na posição: "+(buscaSequencialOrdenadaInt(ordenado, num)+1));
        }else{
            System.out.println("Esse valor não foi encontrado");
        }
        
        if(buscaSequencialNaoOrdenadaInt(naoOrdenado, num) > buscaSequencialOrdenadaInt(ordenado, num)){
            System.out.println("O melhor método para essa busca é do tipo ORDENADO");
        }else{
            System.out.println("O melhor método para essa busca é do tipo NÃO ORDENADO");
        }
    }
    
    private static void exercicio03(){
        int apostaMegaSena[] = new int[6];
        int resultadoMegaSena[] = {10,15,17,20,21,35}; 
        int acertos = 0; 
        
        Scanner scanner = new Scanner(System.in);
        
        for (int i = 0; i < apostaMegaSena.length; i++) {
            System.out.println("Informe o " + (i+1)+"° número apostado: ");
            apostaMegaSena[i] = scanner.nextInt();
            if(buscaSequencialOrdenada(resultadoMegaSena, apostaMegaSena[i]) == true){
                acertos += 1;
            }
        }
        
        System.out.println("RESULTADOS COM BASE NO Concurso 2480 (11/05/2022)\n"
                           +"NÚMEROS APOSTADOS: " +Arrays.toString(apostaMegaSena)+"\n"
                           +"RESULTADO: " +Arrays.toString(resultadoMegaSena)+"\n"
                           +"Houve um total de acertos de : "+acertos); 
        
        
        switch(acertos){
            case 4:
                System.out.println("Com esse total de acertos, lhe rendeu um premio de: R$ 1.030,16\n"+
                                   "Juntamente com mais 4.757 ganhadores. Parabéns!");
                break;
            case 5:
                System.out.println("Com esse total de acertos, lhe rendeu um premio de: R$ 46.356,22\n" +
                                    "Juntamente com mais 74 ganhadores. Parabéns!");
                break;
            case 6:
                System.out.println("Com esse total de acertos, lhe rendeu um premio de: R$ 35.000.000,00\n"+
                                   "Você ganhou sozinho. Parabéns!");
                break;
            default:
                System.out.println("Hum...Não foi dessa vez, fica para próxima. Obrigado pela tentativa!");
                break;
        }
    }  
    
    private static void exercicio04(){
        int numeroRa[] = {1,2,3,4,5,6,7,8,9,10};
        String nomesAlunos[] = {"Aluno 1", "Aluno 2", "Aluno 3", "Aluno 4", "Aluno 5","Aluno 6","Aluno 7","Aluno 8","Aluno 9","Aluno 10"};
        int raBuscado ;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println(Arrays.toString(numeroRa)+"\n");
        System.out.println("Informe o RA desejado: ");
        raBuscado = scanner.nextInt();
        System.out.println(buscaSequencialOrdenadaString2(numeroRa,nomesAlunos,raBuscado));
        
    }
    
    
}

